setwd("C:\\Users\\Yashara\\Desktop\\IT24101780_Lab_8_PS")
data<-read.table("Exercise - LaptopsWeights.txt",header=TRUE)
Weight_kg<-data$Weight.kg.
fix(data)
attach(data)

#Exercise 1
popmn<-mean(Weight_kg)
popsd<-sd(Weight_kg)
popmn
popsd

#Exercise 2
n<-6
num_samples<-25
samples<-c()
s.means<-c()
s.sds<-c()

for (i in 1:num_samples){
  s<-sample(Weight_kg, n, replace=TRUE)
  samples<-cbind(samples,s)
  s.means<-c(s.means, mean(s))
  s.sds<-c(s.sds, sd(s))
}

colnames(samples)<-paste0("Sample", 1:num_samples)

#Exercise 3 
samplemean<-mean(s.means)
samplestddev<-sd(s.means)

cat("Mean of Sample Means (samplemean): ", samplemean, "\n")
cat("Standard Deviation of Sample Means (samplestddev): ", samplestddev, "\n")

cat("\nComparison of Means:\n")
popmn
samplemean

n_sqrt<-sqrt(n)
true_std_err<-popsd/n_sqrt

cat("\nComparison of Standard Deviations:\n")
popsd
samplestddev
true_std_err

