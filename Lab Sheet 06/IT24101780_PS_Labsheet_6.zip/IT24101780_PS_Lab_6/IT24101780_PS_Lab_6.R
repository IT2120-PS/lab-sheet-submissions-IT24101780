setwd("C:\\Users\\Yashara\\Desktop\\IT24101780_PS_Lab_6")

#Part_1

1-pbinom(46,50,0.85,lower.tail = FALSE)

#Part_2

dpois(15,12)

